package com.example.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.domain.Department;

public interface DepRepository extends JpaRepository<Department,Integer>{

}
