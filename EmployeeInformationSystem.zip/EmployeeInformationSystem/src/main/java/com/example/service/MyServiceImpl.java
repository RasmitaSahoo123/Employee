package com.example.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.domain.Department;
import com.example.domain.Employee;
import com.example.repository.DepRepository;
import com.example.repository.EmpRepository;

@Service
public class MyServiceImpl implements MyService{
	@Autowired
	private EmpRepository empRepo;
	
	@Autowired
    private DepRepository depRepo;
	
	@Override
	public Employee saveEmp(Employee emp) {
		Employee e=empRepo.save(emp);
		System.out.println("Insert Method Of Service");
		return e;
	}
	
	@Override
	public List<Employee> selectEmp(){
		List<Employee> list=empRepo.findAll();
		System.out.println("Select Method Of Service");
		return list;
	}
	
	@Override
	public Employee getEmployeeById(Integer eid) {
		System.out.println("Employee with ID"+eid);
	    return empRepo.findById(eid).get();
	}
	
	@Override
	public Employee updateEmp(Employee employee) {
		Integer eid=employee.getEid();
		System.out.println(eid);
		String ename=employee.getEname();
		String eaddr=employee.getEaddr();
		String email=employee.getEmail();
		String password=employee.getPassword();
		Employee e=empRepo.findById(eid).get();
		if(e!=null) {
			e.setEid(eid);
			e.setEname(ename);
			e.setEaddr(eaddr);
			e.setEmail(email);
			e.setPassword(password);
		}
		Employee emp=empRepo.save(e);
		System.out.println("Update Method Of Service");
		return emp;
	}
	
	@Override
	public void deleteEmp(Integer eid) {
		System.out.println("Delete Method Of Service");
		empRepo.deleteById(eid);
	}
	
	@Override
	public Department addDepartment(Department department) {
		Department d = depRepo.save(department);
		System.out.println("Department Insert Method Of Service");
		return d;
	}
	
	@Override
	public List<Department> getAllDepartments(){
		List<Department> list=depRepo.findAll();
		System.out.println("Department Select Method Of Service");
		return list;
	}
	
	@Override
	public Department getDepartmentById(Integer did) {
		Department d = depRepo.findById(did).get();
		return d;
	}
	
	@Override
	public Department updateDepartment(Integer did, Department updatedDepartment) {
		Department department = depRepo.findById(did).get();
        if (department != null) {
            department.setDname(updatedDepartment.getDname());
            System.out.println("Department Update Method Of Service");
            return depRepo.save(department);
        }
        return null;
	}
	
	@Override
	public void deleteDepartment(Integer did) {
		System.out.println("Department Delete Method Of Service");
		empRepo.deleteById(did);
	}
}
