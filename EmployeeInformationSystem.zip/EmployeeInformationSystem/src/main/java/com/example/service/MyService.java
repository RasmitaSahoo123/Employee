package com.example.service;

import java.util.List;

import com.example.domain.Department;
import com.example.domain.Employee;

public interface MyService {
	
  public Employee saveEmp(Employee emp);
  
  public List<Employee> selectEmp();
  
  public Employee getEmployeeById(Integer eid);
  
  public Employee updateEmp(Employee employee);
  
  public void deleteEmp(Integer eid);
  
  public Department addDepartment(Department department);
  
  public List<Department> getAllDepartments();
  
  public Department getDepartmentById(Integer did); 
  
  public Department updateDepartment(Integer did, Department updatedDepartment);
  
  public void deleteDepartment(Integer did);
}
