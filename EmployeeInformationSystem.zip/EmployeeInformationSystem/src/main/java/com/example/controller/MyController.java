package com.example.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.domain.Department;
import com.example.domain.Employee;
import com.example.service.MyService;

@RestController
public class MyController {
	
 @Autowired
 private MyService myservice;
 
 public MyController() {
	 System.out.println("Default Controller");
 }
 
 @PostMapping("/save")
 public Employee saveEmployee(@RequestBody Employee employee){
	 Employee emp=myservice.saveEmp(employee);
	 if(emp!=null) {
		 System.out.println("Record Inserted Successfully");
	 }
	 return emp;
 }
 
 @GetMapping("/select")
 public List<Employee> selectEmployee(){
	 List<Employee> emplist=myservice.selectEmp();
	 if(emplist!=null) {
		 System.out.println("Record Fetched Successfully");
	 }
	 return emplist;
 }
 
 @PutMapping("/update")
	public Employee updateEmployee(@RequestBody Employee employee) {
			Employee s = new Employee();
			s.setEid(employee.getEid());
			s.setEname(employee.getEname());
			s.setEaddr(employee.getEaddr());
			s.setEmail(employee.getEmail());
			s.setPassword(employee.getPassword());
			Employee emp = myservice.updateEmp(s);
			if (emp != null) {
				System.out.println("Record Updated Sucessfully");
			}
		    return emp;
	}
 
 @DeleteMapping("/delete/{eid}")
	public void deleteEmployee(@PathVariable("eid") Integer eid) {
		   myservice.deleteEmp(eid);
		   System.out.println("Record Deleted Sucessfully");
    }
 
 @PostMapping("/add")
 public Department saveDepartment(@RequestBody Department department) {
     if (department.getEmployee() != null && department.getEmployee().getEid() != null) {
         Employee employee = myservice.getEmployeeById(department.getEmployee().getEid());
         if (employee != null) {
             department.setEmployee(employee);
             employee.getDepartments().add(department); 
         }
     }
     return myservice.addDepartment(department);
 }
 
 @GetMapping("/fetch")
 public List<Department> selectDepartments(){
	 List<Department> emplist=myservice.getAllDepartments();
	 if(emplist!=null) {
		 System.out.println("Department Record Fetched Successfully");
	 }
	 return emplist;
 }
 
 @GetMapping("/view/{did}")
 public Department getDepartmentById(@PathVariable("did") Integer did) {
     return myservice.getDepartmentById(did);
 }
 
 @PutMapping("/edit/{did}")
 public Department updateDepartment(@PathVariable("did") Integer did, @RequestBody Department department) {
	 System.out.println("Department Record Updated Successfully");
     return myservice.updateDepartment(did, department);
 }
 
 @DeleteMapping("/remove/{did}")
 public void deleteDepartment(@PathVariable("did") Integer did) {
     myservice.deleteDepartment(did);
     System.out.println("Department Record Deleted Sucessfully");
 }
}
